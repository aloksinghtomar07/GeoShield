import React, { useState } from 'react';
import { User, UserRole } from '../types';
import { 
  UserCheck, 
  Lock, 
  Mail, 
  UserPlus, 
  ShieldAlert, 
  Building, 
  Phone, 
  CheckCircle2, 
  AlertCircle 
} from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (user: User) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onLoginSuccess,
}) => {
  const [mode, setMode] = useState<'signin' | 'signup'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [role, setRole] = useState<UserRole>('authority');
  const [agency, setAgency] = useState('State Disaster Management Authority (SDMA NER)');
  const [phone, setPhone] = useState('+91 94350 00000');
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    const endpoint = mode === 'signin' ? '/api/auth/login' : '/api/auth/register';
    const payload = mode === 'signin' 
      ? { email, password }
      : { name, email, password, role, agency, phone };

    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Authentication failed');
      }

      onLoginSuccess(data.user);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Something went wrong. Please check your credentials.');
    } finally {
      setIsLoading(false);
    }
  };

  // Quick Demo Account Pre-fill
  const selectDemoAccount = (demoRole: UserRole) => {
    if (demoRole === 'authority') {
      setEmail('mukul.sharma@ner-disaster.gov.in');
      setPassword('pass123');
      setName('Dr. Mukul Sharma');
      setAgency('State Disaster Management Authority (SDMA NER)');
      setRole('authority');
    } else if (demoRole === 'responder') {
      setEmail('anamika.borah@sdrf.gov.in');
      setPassword('pass123');
      setName('Sub-Inspector Anamika Borah');
      setAgency('SDRF 1st Bn Quick Response Team');
      setRole('responder');
    } else {
      setEmail('citizen@geoshield.ai');
      setPassword('pass123');
      setName('Pranjal Barua');
      setAgency('Guwahati Citizen Volunteer');
      setRole('citizen');
    }
    setMode('signin');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
        {/* Header */}
        <div className="p-6 bg-slate-900 text-white relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-md"
          >
            ✕
          </button>
          <div className="flex items-center gap-2.5 mb-2">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-500 to-rose-600 flex items-center justify-center text-white font-bold">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <span className="font-bold text-lg tracking-wide">GeoShield AI</span>
          </div>
          <h3 className="text-base font-semibold text-slate-100">
            {mode === 'signin' ? 'Sign In to Your Account' : 'Create an Account'}
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Access real-time early warning telemetry, live GIS layers, and SDRF rescue dispatch.
          </p>
        </div>

        {/* Quick Demo Selector */}
        <div className="px-6 pt-4 pb-2 bg-slate-50 border-b border-slate-200 flex items-center justify-between text-xs">
          <span className="text-slate-500 font-medium">Quick Demo Profiles:</span>
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => selectDemoAccount('authority')}
              className="px-2 py-1 rounded bg-purple-100 hover:bg-purple-200 text-purple-900 font-bold text-[11px] transition"
            >
              Authority
            </button>
            <button
              type="button"
              onClick={() => selectDemoAccount('responder')}
              className="px-2 py-1 rounded bg-amber-100 hover:bg-amber-200 text-amber-900 font-bold text-[11px] transition"
            >
              SDRF
            </button>
            <button
              type="button"
              onClick={() => selectDemoAccount('citizen')}
              className="px-2 py-1 rounded bg-blue-100 hover:bg-blue-200 text-blue-900 font-bold text-[11px] transition"
            >
              Citizen
            </button>
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl text-xs flex items-center gap-2 font-medium">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {mode === 'signup' && (
            <>
              <div>
                <label className="font-bold text-slate-700 block mb-1">Full Name:</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Dr. Mukul Sharma"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-900 outline-none focus:ring-1 focus:ring-blue-500"
                  required
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Select Role:</label>
                <select
                  value={role}
                  onChange={(e) => setRole(e.target.value as any)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-900 font-medium outline-none"
                >
                  <option value="authority">District Disaster Management Authority (SDMA / DM)</option>
                  <option value="responder">Emergency First Responder (NDRF / SDRF)</option>
                  <option value="citizen">Citizen Volunteer / Field Reporter</option>
                </select>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Agency / Department:</label>
                <input
                  type="text"
                  value={agency}
                  onChange={(e) => setAgency(e.target.value)}
                  placeholder="e.g. Assam State Disaster Management Authority"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-900 outline-none"
                />
              </div>
            </>
          )}

          <div>
            <label className="font-bold text-slate-700 block mb-1">Email Address:</label>
            <div className="relative">
              <Mail className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@agency.gov.in"
                className="w-full pl-8 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-900 outline-none focus:ring-1 focus:ring-blue-500"
                required
              />
            </div>
          </div>

          <div>
            <label className="font-bold text-slate-700 block mb-1">Password:</label>
            <div className="relative">
              <Lock className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-8 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-900 outline-none focus:ring-1 focus:ring-blue-500"
                required
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm shadow-xs transition disabled:opacity-50"
          >
            {isLoading 
              ? 'Processing...' 
              : mode === 'signin' ? 'Sign In' : 'Create an Account'}
          </button>

          <div className="text-center pt-2">
            {mode === 'signin' ? (
              <p className="text-slate-500 text-xs">
                Don't have an account?{' '}
                <button
                  type="button"
                  onClick={() => setMode('signup')}
                  className="text-blue-600 font-bold hover:underline"
                >
                  Create an Account
                </button>
              </p>
            ) : (
              <p className="text-slate-500 text-xs">
                Already registered?{' '}
                <button
                  type="button"
                  onClick={() => setMode('signin')}
                  className="text-blue-600 font-bold hover:underline"
                >
                  Sign In
                </button>
              </p>
            )}
          </div>
        </form>
      </div>
    </div>
  );
};
