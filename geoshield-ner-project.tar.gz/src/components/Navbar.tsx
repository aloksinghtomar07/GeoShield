import React from 'react';
import { 
  AlertTriangle, 
  Volume2, 
  VolumeX, 
  Globe, 
  Radio, 
  CloudRain, 
  PhoneCall,
  WifiOff,
  User as UserIcon
} from 'lucide-react';
import { User } from '../types';

interface NavbarProps {
  currentLanguage: 'en' | 'hi' | 'as' | 'bn';
  onSelectLanguage: (lang: 'en' | 'hi' | 'as' | 'bn') => void;
  onTriggerSiren?: () => void;
  onToggleSiren?: () => void;
  isSirenPlaying?: boolean;
  isSirenActive?: boolean;
  isOfflineMode: boolean;
  onToggleOffline: () => void;
  user: User | null;
  onOpenAuth: () => void;
  unreadAlertsCount?: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentLanguage,
  onSelectLanguage,
  onTriggerSiren,
  onToggleSiren,
  isSirenPlaying,
  isSirenActive,
  isOfflineMode,
  onToggleOffline,
  user,
  onOpenAuth,
  unreadAlertsCount = 0
}) => {
  const sirenActive = isSirenActive ?? isSirenPlaying ?? false;
  const handleSirenClick = () => {
    if (typeof onToggleSiren === 'function') {
      onToggleSiren();
    } else if (typeof onTriggerSiren === 'function') {
      onTriggerSiren();
    }
  };
  const languageLabels: Record<string, string> = {
    en: 'English',
    hi: 'हिन्दी (Hindi)',
    as: 'অসমীয়া (Assamese)',
    bn: 'বাংলা (Bengali)'
  };

  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-xs">
      {/* Top Ticker: Live IMD / Sentinel Radar Telemetry Banner */}
      <div className="bg-amber-500/10 border-b border-amber-200/60 px-4 py-1.5 flex items-center justify-between text-xs text-amber-900">
        <div className="flex items-center gap-2 overflow-hidden">
          <span className="inline-flex items-center gap-1 font-bold text-[11px] px-1.5 py-0.5 rounded bg-amber-600 text-white shrink-0">
            <Radio className="w-3 h-3 animate-pulse" />
            LIVE TELEMETRY
          </span>
          <span className="truncate font-medium text-slate-800">
            <strong>IMD Nowcast (NER Sector):</strong> Heavy rain cell active over East Jaintia Hills (74mm/6h). NH-06 Sonapur Inclinometer exceeds threshold (4.8°). SDRF Battalion 1 on high standby.
          </span>
        </div>
        <div className="hidden lg:flex items-center gap-4 shrink-0 text-slate-600 font-mono text-[11px]">
          <span className="flex items-center gap-1">
            <CloudRain className="w-3.5 h-3.5 text-blue-600" />
            Cherrapunji: 168mm / 24h
          </span>
          <span className="text-slate-300">|</span>
          <span>Brahmaputra Gauge: +0.42m</span>
        </div>
      </div>

      {/* Main Nav Bar */}
      <div className="px-6 py-3 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div>
            <h1 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <span>NER Disaster Intelligence Command</span>
              <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-200">
                North Eastern Region
              </span>
            </h1>
            <p className="text-xs text-slate-500">
              Assam • Meghalaya • Sikkim • Nagaland • Arunachal • Mizoram
            </p>
          </div>
        </div>

        {/* Right Action Tools */}
        <div className="flex items-center gap-2.5">
          {/* Emergency Siren Test button */}
          <button
            id="emergency-siren-trigger"
            onClick={handleSirenClick}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition shadow-xs ${
              sirenActive
                ? 'bg-rose-600 text-white animate-pulse ring-2 ring-rose-400'
                : 'bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200'
            }`}
          >
            {sirenActive ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-rose-600" />}
            <span>{sirenActive ? 'Stop Siren' : 'Test Siren (Audio+Alert)'}</span>
          </button>

          {/* Offline Mode Toggle */}
          <button
            onClick={onToggleOffline}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition ${
              isOfflineMode
                ? 'bg-amber-100 text-amber-900 border-amber-300'
                : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
            }`}
            title="Simulates tower failure / remote low network"
          >
            <WifiOff className={`w-3.5 h-3.5 ${isOfflineMode ? 'text-amber-700' : 'text-slate-500'}`} />
            <span className="hidden sm:inline">{isOfflineMode ? 'Offline: Vector Cache' : 'Online Sync'}</span>
          </button>

          {/* Multilingual Selector */}
          <div className="relative">
            <div className="flex items-center gap-1 bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-700">
              <Globe className="w-3.5 h-3.5 text-slate-500" />
              <select
                id="language-selector"
                value={currentLanguage}
                onChange={(e) => onSelectLanguage(e.target.value as any)}
                className="bg-transparent text-xs font-medium outline-none cursor-pointer text-slate-800"
              >
                <option value="en">English</option>
                <option value="hi">हिन्दी</option>
                <option value="as">অসমীয়া</option>
                <option value="bn">বাংলা</option>
              </select>
            </div>
          </div>

          {/* User Sign In / Profile Quick Button */}
          <button
            onClick={onOpenAuth}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 text-white hover:bg-slate-800 text-xs font-medium transition shadow-xs"
          >
            <UserIcon className="w-3.5 h-3.5" />
            <span className="hidden md:inline">
              {user ? user.name.split(' ')[0] : 'Sign In'}
            </span>
          </button>
        </div>
      </div>
    </header>
  );
};
